
const FeedBackform = () => {
  return (
    <div>
      <div>Form</div>
    </div>
  )
}

export default FeedBackform
