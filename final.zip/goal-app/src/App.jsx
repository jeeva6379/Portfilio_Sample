// import { useState } from 'react';

// import axios from 'axios';

// import './App.css';

// function App() {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: ''
//   });

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       const response = await axios.post(import.meta.env.VITE_API_URL + '/api/data', formData);

//       console.log('Success:', response.data);
//       setFormData({ name: '', email: '' });
//     } catch (error) {
//       console.error('Error:', error.message);
//     }
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value
//     });
//   };

//   return (
//     <div className="App">
//       <form onSubmit={handleSubmit}>
//         <label>
//           Name:
//           <input type="text" name="name" value={formData.name} onChange={handleChange} />
//         </label>
//         <br />
//         <label>
//           Email:
//           <input type="email" name="email" value={formData.email} onChange={handleChange} />
//         </label>
//         <br />
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// }

// export default App;
