
import { useState, useRef } from "react";
import { useEffect } from "react";

import { Link } from "react-router-dom";
import axios from "axios";

import './Dashboard.css'

const Dashboard = () => {
  const API_URL = import.meta.env.VITE_API_URL;
  const [showCreateNewGoalSheet, setShowCreateNewGoalSheet] = useState(false);
  const [allGoalSheets, setAllGoalSheets] = useState([]);

  const titleRef = useRef("");
  const descRef = useRef("");

  // Get item from local storage
  const userRole = localStorage.getItem("user_role");

  const createNewGoalSheet = async () => {
    if (titleRef.current.value === "") return console.error("Name field is empty");
    if (descRef.current.value === "") return console.error("Description field is empty");
    try {
      const formData = new FormData();
      formData.append("title", titleRef.current.value);
      formData.append("description", descRef.current.value);

      // Send a POST request to the server to create a new goal sheet
      const response = await axios.post(`${API_URL}/api/goal-sheets`, formData, { headers: { "Content-Type": "application/json" } });
      getAllGoalSheets();
      window.location.href = `/goal-sheet/${response.data.id}`;
    } catch (error) {
      // Log any errors that occurred during the fetch request
      console.error("Error:", error);
    }
  };

  const getAllGoalSheets = async () => {
    try {
      // Send a POST request to the server to create a new goal sheet
      const response = await axios.get(`${API_URL}/api/all-goal-sheets`, { headers: { "Content-Type": "application/json" } });

      setAllGoalSheets(response.data);
    } catch (error) {
      // Log any errors that occurred during the fetch request
      console.error("Error:", error);
    }
  };

  useEffect(() => {
    getAllGoalSheets();
  }, []);

  const handleDeleteGoalSheet = async (id) => {
    try {
      await axios.delete(`${API_URL}/api/delete-goal-sheet/${id}`, { headers: { "Content-Type": "application/json" } });
      getAllGoalSheets();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="container">
      <h2>Dashboard</h2>
      <hr />
      {userRole === "Employee" && (
        <button
          onClick={() => {
            setShowCreateNewGoalSheet(true);
          }}
        >
          create new goal sheet
        </button>
      )}
      {userRole === "HR" && <button  onClick={() => (window.location.href = "createnewuser")}>Create New User</button>}

      {showCreateNewGoalSheet && (
        <div className="p-2"> 
          <div className="text-center p-3">Create New Goal Sheet</div>
          <div className="p-2"><input ref={titleRef} type="text" placeholder="Goal Sheet Title" /></div>
          <div className="p-2"><input ref={descRef} type="text" placeholder="Description" /></div>
          <div className="p-2 text-center"><button onClick={createNewGoalSheet} className="btn btn-primary">Submit</button></div>
<hr/>
        </div>
      )}
      <div className="mt-4">
        <h4>Goal Sheets</h4>
        <div className="mt-4" style={{overflowX: 'auto'}}>
          {allGoalSheets.length > 0 ? (
            <table className="table ">
              <thead>
                <tr>
                  <th >Title</th>
                  <th >Description</th>
                  <th >Tasks</th>
                  <th >Status</th>
                  <th >Actions</th>
                </tr>
              </thead>
              <tbody>
                {allGoalSheets.map((sheet) => (
                  <tr key={sheet._id}>
                    <td>{sheet.title}</td>
                    <td>{sheet.description}</td>
                    <td>{sheet.tasks.length}</td>

                    {userRole === "Employee" && (
                      <td>
                        <button onClick={() => handleDeleteGoalSheet(sheet._id)}>Delete</button>
                      </td>
                    )}
                    { userRole === 'Employee' &&(sheet.sheetSubmitted && <td>
                      Submitted
                    </td>)}
                    <td>
                      {sheet.sheetStatus}
                    </td>

                    {userRole === "Employee" && (
                      <td>
                        <Link to={`/goal-sheet/${sheet._id}`}>
                          <button>Edit</button>
                        </Link>
                      </td>
                    )}
                    {userRole !== "Employee" && (
                      <td>
                        {" "}
                        <Link to={`/goal-sheet/${sheet._id}`}>
                          <button>View</button>
                        </Link>
                      </td>
                    )}
                    
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center opacity-50">You have no goal sheets to display.</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
