module.exports = ["approved", 
"not approved", 
"returned for correction", 
"under review",
"postponed"]