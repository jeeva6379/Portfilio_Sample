module.exports = ["HR", "Reporting Manager", "Employee"];
